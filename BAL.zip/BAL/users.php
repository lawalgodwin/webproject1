<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="axios.min.js"></script>
</head>
<body>
    <script>
        var fetchUsers = function() {
            axios.get('http://localhost/bal/scripts/selectuser.php?')
            .then(data => console.log(data))
            .catch((err) => console.log(err));
        }
        window.addEventListener('load', fetchUsers, false);
    </script>
</body>
</html>