<?php 
 session_start();
 if (!isset($_SESSION['username'])) {
     header('location: signin.php');
 }
    require_once '../config.php';

if ($link) {
    // echo 'connected';
    $userlist = array();
    $pro_num = array();
    $serial = 0;
    // $stmt2 = "SELECT project_name FROM projects WHERE client_id='w01acxsn'";
    // $client_projects = $link->query($stmt2);
    // $rowcount = $client_projects->num_rows;
    // echo $rowcount;
    $stmt = 'SELECT unique_id, id, client_name, phone, email FROM users ';
    $allusers = $link->query($stmt);
    while ($row = $allusers->fetch_array()) {
        $p = $row['unique_id'];
        $stmt2 = "SELECT project_name FROM projects WHERE client_id='$p'";
        $client_projects = $link->query($stmt2);
        $rowcount = $client_projects->num_rows;
        ++$serial;
        // echo "<div><a href='myprojects.php?c_id=".$row['unique_id']."'>".$row['client_name'].'</a></div>';
        array_push($userlist, [$row['unique_id'], $row['client_name'], $row['phone'], $row['email'], $rowcount, $serial]);
        array_pop($pro_num);
    }
} else {
    die('not connected');
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Client List</title>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <link rel="shortcut icon" type="image/x-icon" href="../assets/favicon (3).ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; padding-top: 70px; }
        .wrapper{ width: 350px; padding: 20px; }
        .centre-div{margin: 0 auto; width: 50%}
        .white-text { color: #fff; }
        .div-left{float: left; margin-top: 10px}
    </style>
</head>
<body>
    <div>
    <div>
   <nav class="navbar bg-primary navbar-fixed-top">
     <div class="container-fluid">
      <div class="navbar-header">
       <a class="navbar-brand" href="#"><img src="../assets/logo3.png" alt="" style="height: 35px"/></a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#" class="white-text">Home</a></li> -->
      <!-- <li><a href="#" class="white-text">Page 1</a></li> -->
      <li><a href="create_user.php" class="white-text">Create Users</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="signup.php" class="white-text"><span class="glyphicon glyphicon-home "></span>Home</a></li>
            <li><a href="logout.php" class="white-text"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>
        </div>
        </nav>
        </div>
    <!-- <div class="container centre-div">
      <h5 class=" text-center text-uppercase">Create A User</h5>
            <form action="./users.php" method="POST">
        <div class="form-group">
            <label for="companyname">Client Name</label>
            <input type="text" name="companyname" required class="form-control" id="companyname" placeholder="eg The Adewales">
        </div>
            <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" name="phone" required class="form-control" id="phone" placeholder="Phone Number">
        </div>
        <div class="form-group">
            <label for="projectname">Email</label>
            <input  name="email" type="email" required class="form-control" id="email" placeholder="email">
        </div>
            <button type="submit" class="btn btn-primary">Create</button>
            </form>
            <div class="div-left">
                <a href="./users_list.php" class="">VIEW USERS</a>
            </div>
            </div> -->
            <div class="container">
  <h2>Clients Details</h2>
  <!-- <p>You Have Administrative Control To All Clients All</p>             -->
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Serial Number</th>
        <th>Clients</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Projects</th>
      </tr>
    </thead>
    <tbody>
    <?php
    foreach ($userlist as $user) {
        echo
      "<tr>
        <td>$user[5]</td>
        <td>$user[1]</td>
        <td>$user[2]</td>
        <td>$user[3]</td>
        <td>
            number of projects <span class='badge'>$user[4]</span>
            <a href='myprojects.php?user=$user[0]' class='btn btn-link'> Click To View Projects</a>
        </td>
      </tr>";
    }
      ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html>