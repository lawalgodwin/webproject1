        <?php
        header('Access-Control-Allow-Origin: *');
        ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>index</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="" rel="stylesheet">
    </head>
    <body>
          <?php
           $errors = array();
$uploadedFiles = array();
$extension = array('jpeg', 'jpg', 'png', 'gif');
$bytes = 1024;
$KB = 1024;
$totalBytes = $bytes * $KB;
$UploadFolder = '../uploads';
$project_id = $_REQUEST['project_id'];
$counter = 0;
    $conn = mysqli_connect('localhost', 'baldb', 'password', 'baldb');

foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
    $temp = $_FILES['files']['tmp_name'][$key];
    $name = $_FILES['files']['name'][$key];

    if (empty($temp)) {
        break;
    }

    ++$counter;
    $UploadOk = true;

    if ($_FILES['files']['size'][$key] > $totalBytes * 2) {
        $UploadOk = false;
        array_push($errors, $name.' file size is larger than the 1 MB.');
    }

    $ext = pathinfo($name, PATHINFO_EXTENSION);
    if (in_array($ext, $extension) == false) {
        $UploadOk = false;
        array_push($errors, $name.' is invalid file type.');
    }

    if (file_exists($UploadFolder.'/'.$name) == true) {
        $UploadOk = false;
        array_push($errors, $name.' file already exist.');
    }

    if ($UploadOk == true) {
        move_uploaded_file($temp, $UploadFolder.'/'.$name);
        array_push($uploadedFiles, $name);
    }
    if ($UploadOk) {
        $filename = basename($name, $ext);
        $newFileName = $filename.$ext;
        move_uploaded_file($_FILES['files']['tmp_name'][$key], '../uploads/'.$newFileName);
        $filepath = 'uploads/'.$newFileName;

        $query = "INSERT INTO images(image, imagename, project_id) VALUES('$filepath','".$newFileName."','$project_id')";

        mysqli_query($conn, $query);
    }
}

if ($counter > 0) {
    header('location: admin_page.php');
    if (count($errors) > 0) {
        echo '<b>Errors:</b>';
        echo '<br/><ul>';
        foreach ($errors as $error) {
            echo '<li>'.$error.'</li>';
        }
        echo '</ul><br/>';
    }

    if (count($uploadedFiles) > 0) {
        echo '<b>Uploaded Files:</b>';
        echo '<br/><ul>';
        foreach ($uploadedFiles as $fileName) {
            echo '<li>'.$fileName.'</li>';
        }
        echo '</ul><br/>';

        echo count($uploadedFiles).' file(s) are successfully uploaded.';
    }
} else {
    echo 'Please, Select file(s) to upload.';
}

            ?>
    </body>
</html>
            
        
       