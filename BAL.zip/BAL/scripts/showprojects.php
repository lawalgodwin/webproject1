<?php

    echo $_GET['user_id'];
