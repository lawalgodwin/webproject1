<?php

header('Access-Control-Allow-Origin: *');
require '../config.php';
require '../vendor/phpmailer/phpmailer/PHPMailerAutoload.php';
//receive input from form

$projectowner = $_REQUEST['companyname'];
$email = $_REQUEST['email'];
$projectname = $_REQUEST['projectname'];
$details = $_REQUEST['details'];
$location = $_REQUEST['location'];

$characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
$string = '';
 $max = strlen($characters) - 1;
 for ($i = 0; $i < 8; ++$i) {
     $string .= $characters[mt_rand(0, $max)];
 }

$UNIQUE_KEY = $string;

if (empty(trim($email))) {
    echo 'Please enter your email address.';
} else {
    $email = trim($_POST['email']);
}

//prepare sql query statement

//  $link = new mysqli('localhost', 'baldb', 'password', 'baldb');

if ($link) {
    echo 'You are connected to the database';
}

// Attempt insert query execution
$sql = "INSERT INTO projects (ownername, email, projectname, projectlocation,project_id, details) VALUES ('$projectowner', '$email', '$projectname','$location','$UNIQUE_KEY','$details')";
if (mysqli_query($link, $sql)) {
    echo 'Records inserted successfully.';
    $tablesql = 'CREATE TABLE  '.$UNIQUE_KEY.'(
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    imagepath VARCHAR(255) NOT NULL,
    imagename VARCHAR(255) NOT NULL
        )';
    if (mysqli_query($link, $tablesql)) {
        echo 'table created successfully';
    } else {
        echo ' sUnable to create Table';
    }
} else {
    echo "ERROR: Could not able to execute $sql. ".mysqli_error($link);
}

// Close connection
mysqli_close($link);
$mail = new PHPMailer(true);
$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'godwinl200@gmail.com';          // SMTP username
$mail->Password = '08108017189'; // SMTP password
$mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                          // TCP port to connect to

$mail->setFrom('godwinl200@gmail.com', 'Godwin');
$mail->addReplyTo('godwinl200@gmail.com', 'Users');
$mail->addAddress($email);   // Add a recipient
// $mail->addCC('godwinl200@gmail.com');
// $mail->addBCC('godwinl200@gmail.com');

$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '<h4>Dear  '.ucwords($projectowner).', Your BAL Project Has Been Created</h4>';
$bodyContent .= '<p>Your unique ID is <b>'.$UNIQUE_KEY.'</b></p>';
$bodyContent .= '<p>To follow Up with the Progress of your Project <i>Please</i></p>';
$bodyContent .= '<p><a href="http://www.google.com">DOWNLOAD APP FOR ANDROID DEVICE HERE.. </a><b>or</b></p>';
$bodyContent .= '<a href="http://www.google.com">DOWNLOAD APP FOR IOS DEVICE HERE.. </a>';
$mail->Subject = 'Email from Localhost by Godwin';
$mail->Body = $bodyContent;

if (!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: '.$mail->ErrorInfo;
} else {
    echo 'Message has been sent';
    // session_start();
    header('location: projects.php');
}
/*You can send multiple attachments with email by using the following code.
Add attachments*/
// $mail->addAttachment('/var/tmp/file.tar.gz');
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');
 // Optional name
 ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <script src="" async defer></script>
    </body>
</html>