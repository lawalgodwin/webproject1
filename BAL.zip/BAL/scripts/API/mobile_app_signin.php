<?php
    require_once '../../config.php';
    require_once '../Simple-Json-PHP/includes/json.php';
    use Simple\json;

    $json = new json();
    $unique_ids = array();
    $object = new stdClass();
    $json->data = $object;
  $password = trim($_GET['unique_id']);

$Sql_Query = "SELECT * FROM users WHERE unique_id = '$password' ";

$check = mysqli_fetch_array(mysqli_query($link, $Sql_Query));

if (isset($check)) {
    $SuccessLoginMsg = 'Login Success!';

    // Converting the message into JSON format.
    $SuccessLoginJson = json_encode($SuccessLoginMsg);
    echo $SuccessLoginJson;
} else {
    $InvalidMSG = 'Invalid ID Please Try Again';

    // Converting the message into JSON format.
    $InvalidMSGJSon = json_encode($InvalidMSG);

    // Echo the message.
    echo $InvalidMSGJSon;
}

mysqli_close($link);
