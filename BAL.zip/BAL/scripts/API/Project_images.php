<?php

require_once '../../config.php';
require_once '../Simple-Json-PHP/includes/json.php';
use Simple\json;

$json = new json();
$myimages = array();
$images = array();
$uri = 'uri';
$project_id = trim($_GET['project_id']);
if ($link) {
    // echo 'connected';
    $stmt = "SELECT `id`, `imagename` FROM images WHERE project_id='$project_id'";
    $result = $link->query($stmt);
    while ($row = $result->fetch_array()) {
        array_push($myimages, $row['imagename']);
    }
    foreach ($myimages as $value) {
        array_push($images, ['uri' => "http://192.168.0.150/bal/uploads/$value", 'thumbnail' => "http://192.168.0.150/bal/uploads/$value"]);
    }
    $message_if_null = 'no image';
    if (count($images) < 1) {
        echo json_encode($message_if_null);
    // echo count($images);
    } else {
        // $object = new stdClass();
        // $object->images = $images;
        // $json->data = $object;
        // $json->send();
        echo json_encode($images);
    }
}
