<?php
    require_once '../../config.php';
    require_once '../Simple-Json-PHP/includes/json.php';
    use Simple\json;

    $json = new json();
    $myprojects = array();
    $unique_id = trim($_GET['unique_id']);
    if ($link) {
        // echo 'connected';
        $stmt = "SELECT `id`, `client_id` ,`project_name` FROM projects WHERE client_id='$unique_id'";
        $result = $link->query($stmt);
        while ($row = $result->fetch_array()) {
            array_push($myprojects, [$row['id'], $row['project_name']]);
        }
        $object = new stdClass();
        $object->projects = $myprojects;
        $json->data = $object;
        $json->send();
    }
