<?php

    require '../config.php';

    if (!$link) {
        echo 'not connected';
    } else {
        $client_id = $_REQUEST['client_id'];
        $project_name = $_REQUEST['project_name'];
        $project_description = $_REQUEST['details'];
        $project_location = $_REQUEST['location'];
        $project_status = false;
        $stmt = "INSERT INTO projects(client_id, project_name, project_description,project_location,project_status) VALUES ('$client_id', '$project_name', '$project_description','$project_location','$project_status')";
        $link->query($stmt);
        header('location: myprojects.php?user='.$client_id.'');
    }
