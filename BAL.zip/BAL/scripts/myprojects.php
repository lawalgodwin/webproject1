<?php
    session_start();
 if (!isset($_SESSION['username'])) {
     header('location: signin.php');
 }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>My Projects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="../assets/favicon (3).ico">    
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="main.js"></script>
    <style type="text/css">
        body{ font: 14px sans-serif; padding: 70px}
        .wrapper{ width: 350px; padding: 20px; }
        .centre-div{margin: 0 auto; width: 50%}
        .white-text { color: #fff; }
        .div-left{float: left; margin-top: 10px}
    </style>
</head>
<body>
   <div>
   <nav class="navbar bg-primary navbar-fixed-top">
     <div class="container-fluid">
      <div class="navbar-header">
       <a class="navbar-brand" href="#"><img src="../assets/logo3.png" alt="" style="height: 35px"/></a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#" class="white-text">Home</a></li> -->
      <!-- <li><a href="#" class="white-text">Page 1</a></li> -->
      <!-- <li><a href="#" class="white-text">Page 2</a></li> -->
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="admin_page.php" class="white-text"><span class="glyphicon glyphicon-user "></span>Choose User</a></li>
            <li><a href="logout.php" class="white-text"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>
        </div>
        </nav>
        </div>
    <div class="container centre-div">
        <a href="./create_projects.php" class=" btn btn-link text-uppercase text-center">ADD PROJECTS</a>
        <?php

        require_once '../config.php';

        if ($link) {
            if (isset($_REQUEST['user'])) {
                $client_id = trim($_REQUEST['user']);
                // if (!preg_match("/[0-9]+$/", trim($client_id))) {
                //     die('INVALID USER');
                // }
                // $selecteduserid = $_REQUEST['user'];
                // echo $client_id;
                $project_list = array();
                $query = "SELECT id,project_name,project_location,project_description FROM projects WHERE client_id='$client_id'";
                $projects = $link->query($query);
                // var_dump($projects);
                while ($row = $projects->fetch_array()) {
                    // echo "<div><a href='myprojects.php?p_id=".$row['id']."'>".$row['project_name'].'</a></div>';
                    array_push($project_list, [$row['id'], $row['project_name'], $row['project_description'], $row['project_location']]);
                }
                if (count($project_list) < 1) {
                    echo '<h4>No Projects for the selected user</h4>';
                }
            }
        }

        ?>
    </div>
    <!-- <div class="container centre-div">
            <h4 class=" text-capitalize text-center">Upload Images For The Selected Project</h4>
         <form action='./upload.php' method="POST" class="" method="post" enctype="multipart/form-data">
            <div class="">
            <label for="projectMenu" style="margin-top: .5em">Select Project From The Menu</label>
                <select name="project_id" id="projectMenu" required class=" form-control text-uppercase">
                    <?php 
                    // foreach ($project_list as $value) {
                    //     echo '<option value="'.$value[0].'">'.$value[1].'</option>';
                    // }
                    ?>
                </select>
                </div>
                <div style="margin-top: 1.2em">
                <label for="exampleFormControlFile1" style="margin-top: .5em"> Select Project Image(s)</label>
                <input type="file"
                        required
                       name="files[]"
                       class="form-control" 
                       id="exampleFormControlFile1"
                       accept='image/*'
                       multiple/>
              </div>
               <input type="submit" value="UPLOAD" class="btn btn-group-sm btn-primary" style="margin-top: .5em"/>
             </form>
    </div> -->
              <div class="container">
  <h2>Project Details</h2>
  <!-- <p>You Have Administrative Control To All Clients All</p>             -->
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Project Name</th>
        <th>Project Description</th>
        <th>Geographical Location</th>
        <th>Please hold down <kbd>Ctrl</kbd> key <cite>or</cite> <kbd>Shift +</kbd> arrow keys to select multiple images</th>
      </tr>
    </thead>
    <tbody>
    <?php
    foreach ($project_list as $project) {
        echo
      "<tr>
        <td>$project[1]</td>
        <td>$project[2]</td>
        <td>$project[3]</td>
        <td>
                <form class='navbar-form navbar-left' action='./upload.php?project_id=$project[0]' method='POST' method='post' enctype='multipart/form-data'>
                    <div class='form-group'>
                    <input type='file' class='form-control' name='files[]' accept='image/*' multiple required placeholder='Search'>
                    </div>
                    <button type='submit' class='btn btn-primary'>UPLOAD</button>
                </form>
        </td>
      </tr>";
    }
      ?>
    </tbody>
  </table>
</div>
</body>
</html>