<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>welcome</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <form action="./users.php" method="POST">
  <div class="form-group">
    <label for="companyname">Client Name</label>
    <input type="text" name="companyname" class="form-control" id="companyname" placeholder="eg The Adewales">
  </div>
  <div class="form-group">
    <label for="username">User Name</label>
    <input type="text" name="username" class="form-control" id="username" placeholder="user name">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control" id="companyname" placeholder="password">
  </div>
  <div class="form-group">
    <label for="projectname">Email</label>
    <input  name="email" type="email" class="form-control" id="email" placeholder="email">
  </div>
      <button type="submit" class="btn btn-primary">Create</button>
</form>
<!-- <a href="./signin.php">sign in</a> -->
</body>
</html>
