<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Projects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <form action='./upload.php' method="POST" method="post" enctype="multipart/form-data">
     <div class="form-group">
            <label for="exampleFormControlFile1"> file input</label>
            <input type="file"  name="files[]"
            class="form-control-file" 
            id="exampleFormControlFile1"
            accept='image/*'
            multiple/>
        </div>
  <button type="submit">UPLOAD</button>
</form>
</body>
</html>