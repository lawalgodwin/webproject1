<?php

header('Access-Control-Allow-Origin: *');

require_once '../config.php';
require '../vendor/phpmailer/phpmailer/PHPMailerAutoload.php';

// $username = $_REQUEST['username'];
$phone = $_REQUEST['phone'];
$client_name = $_REQUEST['companyname'];
$email = $_REQUEST['email'];

$characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
$string = '';
$max = strlen($characters) - 1;
for ($i = 0; $i < 8; ++$i) {
    $string .= $characters[mt_rand(0, $max)];
}

$UNIQUE_KEY = $string;
if (empty(trim($email))) {
    echo 'Please enter your email address.';
} else {
    $email = trim($_POST['email']);
}
$mail = new PHPMailer(true);

if ($link) {
    echo 'connected';
    $sql = "INSERT INTO `users`( `client_name`, `email`,`phone`,`unique_id`) VALUES ('$client_name','$email','$phone','$UNIQUE_KEY')";
    $link->query($sql);
    mysqli_close($link);
    $mail->isSMTP();                            // Set mailer to use SMTP
    $mail->Host = 'mail.supremecluster.com';             // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'projects@brandaluminium.com';          // SMTP username
    $mail->Password = 'Password@1'; // SMTP password
    $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 2525;                          // TCP port to connect to

    $mail->setFrom('projects@brandaluminium.com', 'Godwin');
    $mail->addReplyTo('projects@brandaluminium.com', 'Users');
    $mail->addAddress($email);   // Add a recipient
    // // $mail->addCC('godwinl200@gmail.com');
    // // $mail->addBCC('godwinl200@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML

    $bodyContent = '<h4>Dear  '.ucwords($client_name).', Your BAL Project Has Been Created</h4>';
    $bodyContent .= '<p>Your unique ID is <b>'.$UNIQUE_KEY.'</b></p>';
    $bodyContent .= '<p>To follow Up with the Progress of your Project <i>Please</i></p>';
    $bodyContent .= '<p><a href="http://www.google.com">DOWNLOAD APP FOR ANDROID DEVICE HERE.. </a><b>or</b></p>';
    $bodyContent .= '<a href="http://www.google.com">DOWNLOAD APP FOR IOS DEVICE HERE.. </a>';
    $mail->Subject = 'Email from Localhost by Godwin';
    $mail->Body = $bodyContent;

    if (!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: '.$mail->ErrorInfo;
    } else {
        echo 'Message has been sent';
        //     // session_start();
        header('location: admin_page.php');
    }
}
