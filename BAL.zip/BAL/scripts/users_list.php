<?php
session_start();
 if (!isset($_SESSION['username'])) {
     header('location: signin.php');
 }

require_once '../config.php';

if ($link) {
    // echo 'connected';
    $userlist = array();
    $stmt = 'SELECT unique_id, client_name FROM users ';
    $allusers = $link->query($stmt);
    while ($row = $allusers->fetch_array()) {
        // echo "<div><a href='myprojects.php?c_id=".$row['unique_id']."'>".$row['client_name'].'</a></div>';
        array_push($userlist, [$row['unique_id'], $row['client_name']]);
    }
} else {
    die('not connected');
}
// var_dump($userlist);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="../assets/favicon (3).ico">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">  
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
        .centre-div{margin: 0 auto; width: 50%}
        .white-text { color: #fff; }
        .div-left{float: left; margin-top: 10px}
    </style>
</head>
<body>
<div>
   <nav class="navbar bg-primary">
     <div class="container-fluid">
      <div class="navbar-header">
       <a class="navbar-brand" href="#"><img src="../assets/logo3.png" alt="" style="height: 35px"/></a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#" class="white-text">Home</a></li> -->
      <!-- <li><a href="#" class="white-text">Page 1</a></li> -->
      <!-- <li><a href="#" class="white-text">Page 2</a></li> -->
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="admin_page.php" class="white-text"><span class="glyphicon glyphicon-user "></span>Create User</a></li>
            <li><a href="logout.php" class="white-text"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>
        </div>
        </nav>
        </div>
        <div class=" text-center text-uppercase">
            <h4>select user from the menu</h4>
        </div>
        <div class=" container centre-div">
           <form method="POST" action="./myprojects.php" class=" form-inline">
           <div class="" >
              <select name="user" class="form-control text-uppercase text-center" style="width: 80%">
                <?php
                foreach ($userlist as $value) {
                    echo '<option value="'.$value[0].'" >'.$value[1].'</option>';
                }
                ?>
            </select> 
           </div>
           <div class=" form-group">
            <input type="submit" name="submit" class=" btn btn-primary" value="SELECT" style="margin-top: 10px"/>
            </div>
            </form>  
        </div>
</body>
</html>