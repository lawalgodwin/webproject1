<?php
 $link = new mysqli('localhost','baldb','password','baldb');
?>