       <?php
          header('Access-Control-Allow-Origin: *');
//            require ('../config.php');
            require 'phpass-0.4/PasswordHash.php';
            $link = new mysqli('localhost', 'baldb', 'password', 'baldb');
       if (!$link) {
           echo 'unable to access database server';
           exit;
       }
            echo 'connected '.$link->get_server_info();
            $stmt = $link->prepare('INSERT INTO signup(username,email,passwrd) VALUES (?,?,?)');
            $stmt->bind_param('sss', $username, $email, $hashedpassword);
            $hasher = new PasswordHash(8, false);
               $username = $_REQUEST['username'];
               echo $username;
                    $email = trim($_REQUEST['email']);
                    $ckeckemail = filter_var($email, FILTER_VALIDATE_EMAIL);
                if (!$ckeckemail) {
                    echo 'Invalid email format';
                    exit;
                } else {
                    $email = $email;
                }
               echo $email;
               $password = $_REQUEST['password'];
               echo $password;
               $hashedpassword = $hasher->HashPassword($password);
               $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
               $stmt->execute();
               echo 'query executed successful';
               $stmt->close();
               $link->close();
               ?>
