<?php

define('HOST', 'localhost');
define('USERNAME', 'baldb');
define('PASSWORD', 'password');
define('DATABASE_NAME', 'baldb');
 